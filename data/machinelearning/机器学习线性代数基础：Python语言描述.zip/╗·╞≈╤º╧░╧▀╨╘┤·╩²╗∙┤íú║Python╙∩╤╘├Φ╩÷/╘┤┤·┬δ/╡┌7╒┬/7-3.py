z1 = 2 + 1j
z2 = 3 + 5j

print(z1.real)  #实部
print(z2.imag)  #虚部
print(z1+z2)    #加法
print(z1*z2)    #乘法
print(z1.conjugate())  #共轭
print(abs(z1))  #模长

