import numpy as np
u = np.array([[1,2,3]]).T
v = np.array([[5,6,7]]).T
print(u + v)