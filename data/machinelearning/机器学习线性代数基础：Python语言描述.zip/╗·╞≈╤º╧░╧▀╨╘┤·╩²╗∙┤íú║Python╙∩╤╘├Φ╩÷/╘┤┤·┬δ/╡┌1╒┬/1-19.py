import numpy as np
A = np.diag([1, 2, 3, 4, 5])
print(A)