import numpy as np
u = np.array([[3, 5, 2]]).T
v = np.array([[1, 4, 7]]).T
print(np.dot(u,v))