import numpy as np
u = np.array([[1, 2, 3]]).T
print(3*u)