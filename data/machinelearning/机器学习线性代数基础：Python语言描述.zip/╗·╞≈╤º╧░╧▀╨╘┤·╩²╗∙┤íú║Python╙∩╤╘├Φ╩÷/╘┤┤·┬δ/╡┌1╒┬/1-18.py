import numpy as np
A = np.zeros([5, 3])
print(A)