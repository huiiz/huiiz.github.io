import numpy as np
I = np.eye(5)
print(I)