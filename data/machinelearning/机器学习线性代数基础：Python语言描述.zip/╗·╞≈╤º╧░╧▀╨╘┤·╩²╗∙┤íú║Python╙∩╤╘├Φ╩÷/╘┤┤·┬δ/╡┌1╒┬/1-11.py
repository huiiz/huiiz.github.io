import numpy as np
u = np.array([3, 5])
v = np.array([1, 4])
print(np.cross(u, v))