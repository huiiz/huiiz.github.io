import numpy as np
x = np.array([3, 3, 9])
y = np.array([1, 4, 12])
print(np.cross(x, y))