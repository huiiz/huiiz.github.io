import numpy as np
A = np.array([[1, 4],
              [2, 5],
              [3, 6]])
print(2*A)