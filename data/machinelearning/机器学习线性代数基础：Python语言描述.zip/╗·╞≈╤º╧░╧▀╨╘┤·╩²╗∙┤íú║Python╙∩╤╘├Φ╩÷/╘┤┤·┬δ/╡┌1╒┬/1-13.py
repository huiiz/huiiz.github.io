import numpy as np
u = np.array([[1, 2, 3]]).T
v = np.array([[4, 5, 6]]).T
w = np.array([[7, 8, 9]]).T
print(3*u+4*v+5*w)