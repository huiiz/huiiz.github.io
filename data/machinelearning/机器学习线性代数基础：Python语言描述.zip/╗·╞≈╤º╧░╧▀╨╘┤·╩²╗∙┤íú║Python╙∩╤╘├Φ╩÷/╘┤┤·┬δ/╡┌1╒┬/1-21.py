import numpy as np
p = np.array([[1, 2, 3, 4]])
print(p)
print(p.T)