import numpy as np
import matplotlib.pyplot as plt

mean = np.array([0, 0])
conv_1 = np.array([[1, 0],
                 [0, 1]])

conv_2 = np.array([[4, 0],
                 [0, 0.25]])

x_1, y_1 = np.random.multivariate_normal(mean=mean, cov=conv_1, size=3000).T
x_2, y_2 = np.random.multivariate_normal(mean=mean, cov=conv_2, size=3000).T
plt.figure(figsize=(6, 6))
plt.plot(x_1, y_1, 'ro', alpha=0.05)
plt.plot(x_2, y_2, 'bo', alpha=0.05)
plt.gca().axes.set_xlim(-6, 6)
plt.gca().axes.set_ylim(-6, 6)
plt.grid(ls='--')
plt.show()