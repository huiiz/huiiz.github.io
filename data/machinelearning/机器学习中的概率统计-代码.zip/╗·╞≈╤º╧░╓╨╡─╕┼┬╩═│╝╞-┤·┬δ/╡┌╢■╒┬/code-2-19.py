import numpy as np

X = [-2,-1,-1,0,0,1,1,2]
Y = [0,1,-1,2,-2,1,-1,0]

S = np.vstack((X, Y))
print(np.cov(S))