import numpy as np
from scipy.stats import binom


# 一轮迭代处理，更新一次参数值
def single_iter(theta_priors, exper_results):
	"""
	param exper_results：六组试验的观测结果
	param theta_priors：上一轮迭代更新的参数theta_A和theta_B
	"""
	counts = {'A': {'H': 0, 'T': 0}, 'B': {'H': 0, 'T': 0}}
	theta_A = theta_priors['A']
	theta_B = theta_priors['B']
	
	# 迭代计算每组试验的数据
	for result in exper_results:
		num_heads = result['H']
		num_tails = result['T']
		P_A = binom.pmf(num_heads, num_heads + num_tails, theta_A)
		P_B = binom.pmf(num_heads, num_heads + num_tails, theta_B)
		# 计算出硬币A和硬币B各自出现的概率
		weight_A = P_A / (P_A + P_B)
		weight_B = P_B / (P_A + P_B)
		# 更新在当前硬币A和硬币B各自出现的概率下， 硬币A和硬币B各自的正反面次数
		counts['A']['H'] += weight_A * num_heads
		counts['A']['T'] += weight_A * num_tails
		counts['B']['H'] += weight_B * num_heads
		counts['B']['T'] += weight_B * num_tails
	# 经过这一轮，重新估计硬币A和硬币B正面向上的概率
	new_theta_A = counts['A']['H'] / (counts['A']['H'] + counts['A']['T'])
	new_theta_B = counts['B']['H'] / (counts['B']['H'] + counts['B']['T'])
	return {'A': new_theta_A, 'B': new_theta_B}


# 六组试验结果的观测值
exper_results = np.array([{'H': 6, 'T': 4},
						  {'H': 7, 'T': 3},
						  {'H': 8, 'T': 2},
						  {'H': 4, 'T': 6},
						  {'H': 3, 'T': 7},
						  {'H': 5, 'T': 5}])

theta = {'A': 0.7, 'B': 0.4}  # 设定初始的参数值theta_0
iter = 0
total_iter = 10000  # 最多的迭代次数

while iter < total_iter:
	new_theta = single_iter(theta, exper_results)
	print(new_theta)
	delta_change = np.abs(theta['A'] - new_theta['A'])
	if delta_change < 1e-6:
		break
	else:
		theta = new_theta
		iter += 1

print('迭代结束，总共迭代轮数{}'.format(iter))
print('最终估计的参数{}'.format(new_theta))