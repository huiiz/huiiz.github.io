import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from sklearn.datasets.samples_generator import make_blobs

#产生并绘制实验数据
X, y_true = make_blobs(n_samples=1000, centers=4)
fig, ax = plt.subplots(1,2,sharey='row')
ax[0].scatter(X[:, 0], X[:, 1], s=5, alpha=0.5)
ax[0].grid(ls='--')

#高斯混合模型拟合样本
gmm = GaussianMixture(n_components=4)
gmm.fit(X)

#打印GMM三组参数：权重、均值、协方差矩阵
print(gmm.weights_)
print(gmm.means_)
print(gmm.covariances_)

#打印每个样本属于每个高斯分布的概率
print(gmm.predict_proba(X)[:10].round(5))

#通过GMM模型推测每个样本所属的类别
labels = gmm.predict(X)
print(labels)
#不同的类别标记为不同的颜色
ax[1].scatter(X[:, 0], X[:, 1], s=5, alpha=0.5, c=labels, cmap='viridis')
ax[1].grid(ls='--')
plt.show()